function res=transpose(X)
res=transpose(X.data);
end
