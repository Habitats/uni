function res=uplus(X)
res=uplus(X.data);
end
