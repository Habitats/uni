function res=mtimes(X,Y)
res=mtimes(X.data, Y.data);
end
            