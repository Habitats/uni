function res=times(X,Y)
res=times(X.data, Y.data);
end
            