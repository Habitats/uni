function res=gt(X,Y)
res=gt(X.data, Y.data);
end
            