function res=horzcat(X,Y)
res=horzcat(X.data, Y.data);
end
            