function res=uminus(X)
res=uminus(X.data);
end
