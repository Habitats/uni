function res=power(X,Y)
res=power(X.data, Y.data);
end
            