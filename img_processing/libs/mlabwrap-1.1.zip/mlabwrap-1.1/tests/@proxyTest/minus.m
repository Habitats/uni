function res=minus(X,Y)
res=minus(X.data, Y.data);
end
            