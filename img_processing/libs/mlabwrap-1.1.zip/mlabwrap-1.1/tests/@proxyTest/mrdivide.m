function res=mrdivide(X,Y)
res=mrdivide(X.data, Y.data);
end
            