"""Flat rendering mechanism using structural scenegraph observation

Rewritten version that should be core-profile compatible...
"""
from . import flatcore,flatcompat
