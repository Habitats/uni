#include <stdio.h>          // - Just for some ASCII messages
#include <GL/freeglut.h>    // FreeGLUT
#include "visuals.h"        // Header file for our OpenGL functions

void Render() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
// Clean up the colour of the window
	// and the depth buffer
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();

	// push the identity matrix on the stack and apply transformations, then pop
	// (this wasn�t really a part of the assignment, but I figured I could leave
	// it in anyway)
	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslated(-20, 30, -6);
	glRotated(40, 10, -10, 10);
	glutSolidTeapot(20.0);
	glPopMatrix();

	glColor3f(0, 1, 0);
	glPushMatrix();
	glTranslated(0, 5, -20);
	glutWireTeapot(20.0);
	glPopMatrix();

	glColor3f(0, 0, 1);
	glPushMatrix();
	glTranslated(20, -30, 0);
	glutSolidSphere(20.0, 90, 124);
	glPopMatrix();

// since we�re using double buffering, we have one buffer for drawing, and 
// one buffer for viewing. This method swaps these buffers after every
// frame is rendered
	glutSwapBuffers();             
}

void Resize(int w, int h) { // w and h are window sizes returned by glut
	// define the visible area of the window (in pixels)
	if (h == 0) h = 1;
	glViewport(0, 0, w, h);
	// Setup viewing volume
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	//         L,      R,      B,     T,     N,      F
	glOrtho(-50.0f, 50.0f, -50.0f, 50.0f, 100.0f, -100.0f);
}

void Setup() { // DON'T TOUCH IT 
	//Parameter handling
	glShadeModel (GL_SMOOTH);
	glEnable (GL_DEPTH_TEST);
	// polygon rendering mode
	glEnable (GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	//Set up light source
	GLfloat light_position[] = { 0.0, 30.0, -50.0, 0.0 };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glEnable (GL_LIGHTING);
	glEnable (GL_LIGHT0);
	// Black background
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}
